#ifndef FLIGHT_H_INCLUDED
#define FLIGHT_H_INCLUDED

#include <iostream>

#define info(p) (p)->info
#define next(p) (p)->next
#define first(L) ((L).first)
#define nil NULL

using namespace std;

struct jadwalPenerbangan{
    string kode;
    string jenis;
    string tanggal;
    string waktu;
    string asal;
    string tujuan;
    string kapasitas;
};

typedef struct elementJadwal *adr_jadwalP;

typedef jadwalPenerbangan infotype;

struct elementJadwal{
    infotype info;
    adr_jadwalP next;
};

struct ListJadwal{
    adr_jadwalP first;
};

void createListJadwal_1301210537(ListJadwal &L);
adr_jadwalP createElemenJadwal_1301210537(infotype x);
void InsertLastJ_1301210537(ListJadwal &L, adr_jadwalP p);
void ShowJadwal_1301210537(ListJadwal L);
void DeleteFirstJ_1301210537(ListJadwal &L, adr_jadwalP &p);
adr_jadwalP searchJ_1301210537(ListJadwal L, string dari, string ke, string tanggal);

#endif // FLIGHT_H_INCLUDED
