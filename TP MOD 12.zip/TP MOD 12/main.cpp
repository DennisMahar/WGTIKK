#include <iostream>
#include "flight.h"

using namespace std;

int main()
{
    ListJadwal L,cari;
    infotype data;
    adr_jadwalP p;
    int n;
    string kode, jenis, tanggal, waktu, asal, tujuan, kapasitas;

    createListJadwal_1301210537(L);
    cout << "Masukkan Jumlah Jadwal Penerbangan : ";
    cin >> n;
    cout << endl;
    cin.sync();
    for(int i=0;i<n;i++){
        cout<<"Kode Penerbangan : ";
        getline(cin, kode);
        cout<<"Jenis Pesawat : ";
        getline(cin, jenis);
        cout<<"Tanggal Penerbangan : ";
        getline(cin, tanggal);
        cout<<"Waktu Penerbangan : ";
        getline(cin, waktu);
        cout<<"Asal : ";
        getline(cin, asal);
        cout<<"Tujuan : ";
        getline(cin, tujuan);
        cout<<"Kapasitas : ";
        getline(cin, kapasitas);

        data.kode = kode;
        data.jenis = jenis;
        data.tanggal = tanggal;
        data.waktu = waktu;
        data.asal = asal;;
        data.tujuan = tujuan;
        data.kapasitas = kapasitas;
        p = createElemenJadwal_1301210537(data);
        InsertLastJ_1301210537(L,p);
        cout << endl;
    }
    cout << "Jadwal Penerbangan"<<endl;
    ShowJadwal_1301210537(L);
    cout << endl;

    cout << "Jadwal Penerbangan Setelah Di Hapus"<<endl;
    DeleteFirstJ_1301210537(L,p);
    ShowJadwal_1301210537(L);
    cout << endl;

    cout <<"Pencarian Penerbangan Dari Surabaya Ke Malang Tanggal 9 Desember 2022"<<endl;
    adr_jadwalP q = searchJ_1301210537(L, "Surabaya (SUB)","Malang (MLG)","9 Desember 2022");
    createListJadwal_1301210537(cari);
    InsertLastJ_1301210537(cari,q);
    ShowJadwal_1301210537(cari);
    cout << endl;

    return 0;
}
