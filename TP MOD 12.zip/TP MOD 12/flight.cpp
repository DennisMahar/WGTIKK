#include "flight.h"
#include <iostream>

using namespace std;

void createListJadwal_1301210537(ListJadwal &L){
    first(L) = nil;
}

adr_jadwalP createElemenJadwal_1301210537(infotype x){
    adr_jadwalP p = new elementJadwal;
    info(p) = x;
    next(p) = nil;
    return p;
}

void InsertLastJ_1301210537(ListJadwal &L, adr_jadwalP p){
    adr_jadwalP q = first(L);
    if (first(L) == nil){
        first(L) = p;
    }else{
        while(next(q) != nil){
            q = next(q);
        }
        next(q) = p;
    }
}

void ShowJadwal_1301210537(ListJadwal L){
    adr_jadwalP q = first(L);
    if (first(L) == nil){
        cout << "List kosong";
    }else{
        while (q != nil){
            cout << info(q).kode<<" - "<<info(q).jenis<<" - "<<info(q).tanggal<<" - "<<info(q).waktu<<" - "<<info(q).asal<<" - "<<info(q).tujuan<<" - "<<info(q).kapasitas<<endl;
            q = next(q);
        }
    }
}

void DeleteFirstJ_1301210537(ListJadwal &L, adr_jadwalP &p){
    adr_jadwalP q = first(L);
    if (first(L) == nil){
        cout << "List kosong";
    }else{
        while (next(next(q)) != nil){
            q = next(q);
        }
        p = next(q);
        next(q) = nil;
    }
}

adr_jadwalP searchJ_1301210537(ListJadwal L, string dari, string ke, string tanggal){
    adr_jadwalP q = first(L);
    bool status = false;
    if (first(L) == nil){
        cout << "List kosong";
    }else{
        while(q!=nil && !status){
            if (info(q).asal == dari && info(q).tujuan == ke && info(q).tanggal == tanggal){
                status = true;
            }else{
                q = next(q);
            }
        }
    }
    if (status){
        return q;
    }else{
        return nil;
    }
}
